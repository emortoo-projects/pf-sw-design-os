# Marketing OS — SDOS Input Guide

> Use these answers when walking through the SDOS 9-stage pipeline to generate the Marketing OS SDP.
> Marketing OS = Content Creation + Social Media + Email Marketing + SEO + Analytics (merged with Social OS)

---

## Stage 1: Product Definition

### What are you building?

Marketing OS — the growth engine for solo entrepreneurs inside BMHQ. It merges content creation, social media management, email marketing, SEO, and analytics into one AI-powered module. Write a blog post with AI → repurpose it into tweets, LinkedIn posts, and an email newsletter → schedule everything across platforms → track what converts. It replaces Buffer, Mailchimp, ConvertKit, Hootsuite, and WordPress content management. Every piece of content is AI-assisted, every campaign is trackable, and everything connects back to Business OS for lead attribution.

### Who is this for?

Solo founders and small teams who need to market their business but don't have a dedicated marketing person. They know content marketing works but don't have time to write blog posts, manage 4 social platforms, send email newsletters, AND track what's working. They want AI to do the heavy lifting — generate drafts, repurpose content across formats, suggest optimal posting times — while they review and approve.

### What problems does this solve?

1. Content creation takes too long — writing a single blog post takes 3-4 hours without AI help, so it doesn't get done
2. Content stays siloed — a blog post never becomes tweets, a LinkedIn post never becomes an email, each platform is managed separately
3. Social media is time-consuming — posting to 4+ platforms manually, each with different formats and best practices
4. Email marketing is disconnected — newsletter subscribers don't connect to CRM leads, no attribution from email to sale
5. No idea what's working — analytics scattered across Google Analytics, Twitter Analytics, LinkedIn Analytics, email platform dashboards
6. SEO is an afterthought — no keyword research, no optimization, no tracking of what ranks
7. Inconsistent posting schedule — bursts of activity followed by weeks of silence because there's no content calendar

### What are the must-have features?

- **AI Content Studio**: AI-powered editor for blog posts, emails, ad copy, social posts. Provide a topic → AI generates a full draft with SEO-optimized headings. Edit with AI assistance (rewrite, shorten, expand, change tone). Support for long-form (blog), short-form (social), and email formats
- **Content Calendar**: Visual calendar showing all scheduled content across all channels. Drag-and-drop to reschedule. Color-coded by channel (blog=blue, email=purple, social=green). Weekly, monthly, quarterly views. Gap detection ("You have no content planned for next Tuesday")
- **Content Repurposer**: Input one piece of content → AI generates versions for every platform. Blog post → 5 tweets thread + LinkedIn article + Instagram carousel text + email newsletter intro + YouTube video script outline. One click to schedule all versions
- **Social Media Manager**: Connect accounts (X/Twitter, LinkedIn, Instagram, TikTok, Facebook, YouTube). Compose and schedule posts per platform. Optimal time suggestions based on audience. Engagement inbox — reply to comments/DMs from one place. Hashtag suggestions. Image/video attachment support
- **Email Campaign Builder**: Drag-and-drop email template builder. Sequence builder (drip campaigns: Day 1 → Day 3 → Day 7). Newsletter editor with AI content suggestions. Subscriber management with segments and tags. Analytics (open rate, click rate, unsubscribe rate). Integration with Business OS CRM contacts
- **SEO Dashboard**: Keyword research tool (search volume, difficulty, suggestions). On-page SEO checker for content (meta title, description, headings, keyword density). Rank tracking for target keywords. Competitor analysis (what keywords they rank for). Technical SEO alerts (broken links, slow pages)
- **Landing Page Builder**: Drag-and-drop page builder with pre-designed sections. A/B testing (two versions, track conversion). Lead capture forms that feed into Business OS CRM. Custom domains and SSL. Analytics per page (views, conversions, bounce rate)
- **Analytics Hub**: Unified dashboard pulling data from all channels. Content performance (views, engagement, shares per piece). Channel comparison (which platform drives the most traffic/leads). Campaign ROI tracking. Funnel visualization (content view → lead capture → deal → revenue). Attribution (which content piece led to which sale via Business OS)

### What do people use today instead?

Buffer or Hootsuite for social scheduling. Mailchimp or ConvertKit for email. WordPress or Ghost for blogging. Ahrefs or SEMrush for SEO. Google Analytics for web tracking. Canva for graphics. Each tool $20-50/month, separate logins, separate dashboards, no cross-channel attribution.

### What makes yours different?

AI-first content creation — every piece of content starts with AI and gets refined by the human, not the other way around. True cross-channel repurposing — one input becomes content for every platform automatically. Unified analytics — see the full journey from social post → website visit → email signup → deal closed in one dashboard because it connects to Business OS. Inside BMHQ, agents from Agent OS can automate the entire content pipeline. Mission Control monitors all marketing activities.

### Any constraints or preferences?

BMHQModule interface. React + Vite or Next.js. Tailwind + shadcn/ui. PostgreSQL. Accent color: #EC4899 (pink). OAuth connections to social platforms (Twitter/X API, LinkedIn API, Meta Graph API, TikTok API). Email sending via SendGrid or Amazon SES. Rich text editor (TipTap or Plate). Docker-first deployment.

---

## Stage 2: Data Model

### What are the main things your app tracks?

Content, ContentVersion, ContentRepurpose, SocialAccount, SocialPost, SocialEngagement, EmailCampaign, EmailSequence, EmailSequenceStep, EmailTemplate, Subscriber, SubscriberSegment, SubscriberTag, EmailEvent, CalendarEntry, Keyword, KeywordRank, SEOAudit, LandingPage, LandingPageVariant, FormSubmission, ContentAnalytics, ChannelAnalytics, Campaign

### How do these things relate to each other?

A Content piece is the core entity — it can be a blog post, email, or social post draft. Content has ContentVersions (version history). A Content piece generates ContentRepurposes (the same content adapted for different platforms). SocialAccounts are connected platforms. SocialPosts are scheduled posts tied to a SocialAccount and optionally a Content piece. SocialEngagements track likes/comments/shares per SocialPost. EmailCampaigns are one-time sends, EmailSequences are multi-step drips. EmailSequenceSteps belong to a Sequence. EmailTemplates are reusable designs. Subscribers receive emails and have SubscriberTags and belong to SubscriberSegments. EmailEvents track opens/clicks/bounces per subscriber per email. CalendarEntries represent scheduled content across all channels. Keywords are tracked for SEO, with KeywordRank history. LandingPages have LandingPageVariants for A/B testing. FormSubmissions capture leads from landing pages and feed into Business OS. ContentAnalytics and ChannelAnalytics aggregate performance data. Campaigns group content, social posts, and emails into a coordinated marketing push.

### What important details does each thing have?

- **Content**: id, title, type (blog/email/social/ad_copy/landing_page), status (idea/draft/review/published/archived), body (rich text JSON), excerpt, slug, seoTitle, seoDescription, keywords, author, publishedAt, scheduledAt, channel, aiGenerated (boolean), sourceContentId (for repurposed content)
- **SocialPost**: id, socialAccountId, contentId, platform (twitter/linkedin/instagram/tiktok/facebook/youtube), body, mediaUrls, scheduledAt, publishedAt, status (draft/scheduled/published/failed), externalPostId, engagement (JSONB — likes, comments, shares, impressions)
- **Subscriber**: id, email, firstName, lastName, status (active/unsubscribed/bounced/complained), source, subscribedAt, unsubscribedAt, tags, segments, customFields (JSONB), businessOsContactId (link to CRM)
- **EmailCampaign**: id, name, subject, previewText, templateId, body, status (draft/scheduled/sending/sent), segmentId, scheduledAt, sentAt, stats (JSONB — sent, delivered, opened, clicked, bounced, unsubscribed)
- **LandingPage**: id, title, slug, domain, status (draft/published/archived), content (JSONB — page builder data), analytics (JSONB), conversionGoal, formFields

### Any special data needs?

- Rich text content storage (TipTap/Plate JSON format)
- Time-series data for analytics (daily metrics per content/channel)
- OAuth token storage (encrypted) for social platform connections
- Media storage (images, videos) for social posts and landing pages
- Email event tracking (pixel tracking for opens, link tracking for clicks)
- High-volume event ingestion (social engagement, email events)

---

## Stage 3: Database

### Database preference?
PostgreSQL

### How much data?
Medium-high (content grows daily, email events can be millions over time, social engagement data is high-volume)

### Where will the database run?
Local Docker first, production on Railway/Supabase

---

## Stage 4: API Design

### What style of API?
REST

### How should users authenticate?
Shared with BMHQ platform auth

### Any external APIs or services to integrate?
- Twitter/X API v2 (post, schedule, read engagement)
- LinkedIn API (post, read analytics)
- Meta Graph API (Instagram, Facebook posting and analytics)
- TikTok API (post, analytics)
- YouTube Data API (upload, analytics)
- SendGrid or Amazon SES (email sending)
- OpenAI/Anthropic API (content generation — shared via BMHQ AI config)
- Google Search Console API (SEO rank tracking)
- Google Analytics 4 API (website analytics)
- Unsplash API (stock images for content)
- S3-compatible storage (media uploads)

### Any special API requirements?
- OAuth2 flows for connecting social accounts
- Webhook receivers for email events (opens, clicks, bounces)
- Batch scheduling endpoint (schedule 10+ posts at once)
- Content generation endpoint (AI generates content based on topic/keywords/tone)
- Real-time analytics endpoint with date range filtering
- Rate limiting per social platform (respect API rate limits)
- Background job queue for scheduled post publishing

---

## Stage 5: Tech Stack

### Frontend preference?
React + Vite (matching BMHQ)

### Styling?
Tailwind CSS + shadcn/ui

### Rich text editor?
TipTap (for content editor and email builder)

### State management?
Zustand + TanStack Query

### Deployment?
Docker (local first)

---

## Stage 6: Design System

### What vibe?
Creative & energetic but organized. Should feel like a tool that makes marketing fun, not overwhelming.

### Brand colors?
Primary: #EC4899 (pink — creative energy). Accent: #8B5CF6 (purple — for email/campaigns). Channel colors: Twitter blue, LinkedIn blue, Instagram gradient, TikTok black. Success green for published, amber for scheduled, gray for draft.

### Apps to look like?
Buffer (clean social scheduling), ConvertKit (email simplicity), Notion (content writing), Ahrefs (SEO dashboard), Webflow (landing page builder)

### Layout structure?
Sidebar navigation within BMHQ shell. Content editor takes full width when active. Calendar view is the primary navigation paradigm.

### Dark mode?
Both (inherits from BMHQ platform toggle)

---

## Stage 7: Sections / Pages

### What are the main screens or pages?

1. **Dashboard** — Content published this week, email open rates, social engagement summary, top performing content, upcoming scheduled posts, content ideas backlog count, campaign performance overview
2. **Content Studio** — AI-powered editor with sidebar for SEO suggestions, word count, readability score. Content list with status filters. Create new content with AI or from scratch. Version history. Repurpose button that generates cross-platform versions
3. **Content Calendar** — Full-width calendar view (week/month). Each day shows scheduled content cards color-coded by channel. Drag to reschedule. Click to edit. "Schedule gap" warnings. Filter by channel.
4. **Social Manager** — Left: compose area with platform selector, character count, media uploader, hashtag suggestions. Right: feed preview showing how post looks on each platform. Queue view showing upcoming posts. Engagement inbox with reply functionality
5. **Email Campaigns** — Campaign list with stats (sent, opened, clicked). Create campaign: select template → edit content → choose segment → schedule/send. Sequence builder: visual flow editor showing steps with delays. Subscriber growth chart
6. **Subscribers** — Table of subscribers with segment/tag filters. Subscriber detail: activity history, emails received, engagement score. Import/export. Segment builder with conditions (tag=X AND opened last email)
7. **SEO Dashboard** — Keyword list with rank, volume, difficulty, trend. Rank tracking chart over time. Content suggestions based on keyword gaps. Site audit results. Competitor keyword comparison
8. **Landing Pages** — Grid of pages with live/draft status, preview thumbnails, conversion rates. Drag-and-drop page builder with section library. A/B test setup and results. Form builder for lead capture
9. **Analytics** — Unified performance dashboard. Content performance table (all content sorted by engagement). Channel comparison chart. Campaign ROI breakdown. Funnel: impressions → clicks → leads → deals (connected to Business OS). Date range selector, export to PDF
10. **Repurpose Studio** — Input: select source content. Output: AI-generated versions for each connected platform. Edit each version independently. "Schedule All" to push to calendar

### What's the first thing users see after login?

Dashboard showing: content calendar for the current week (miniview), social engagement trend (last 7 days), email campaign performance (last campaign stats), top 3 performing content pieces, "Create Content" and "Schedule Post" quick action buttons. If zero data: onboarding wizard — "Connect your social accounts" → "Write your first post with AI" → "Schedule it."

### Any complex interactions?

- **AI Content Generation**: User provides topic, tone, target audience, keywords → AI generates full blog post with headings, intro, body, conclusion, meta description. User edits inline. "Repurpose" button generates versions for all connected platforms in one click
- **Content Calendar Drag & Drop**: Drag posts between days and time slots. Drag from backlog/ideas onto calendar to schedule. Visual indicator of optimal posting times per platform
- **Email Sequence Builder**: Visual flowchart — add steps (email, wait, condition). Conditions: "if opened → send follow-up, if not → send reminder." Preview the subscriber journey
- **Landing Page Builder**: Drag-and-drop sections (hero, features, testimonials, pricing, CTA, footer). Real-time preview. Form builder with field types. Connect form to Business OS CRM
- **Social Engagement Inbox**: Unified view of comments/replies across all platforms. Reply without leaving BMHQ. Quick responses with AI-suggested replies. Mark as handled/starred/archived

### Which screens display a lot of data?

- **Subscribers** — could be 10,000+ subscribers, needs search, filters, pagination, segment-based views
- **Analytics** — aggregated data across channels and time periods, heavy chart rendering
- **Content list** — hundreds of content pieces over time, needs status/type/channel filters
- **Email events** — millions of open/click events, needs aggregation not raw display
- **Social engagement** — high-volume likes/comments/shares data, needs efficient polling

---

## Stage 8: Infrastructure

### Environments?
Local + Production

### CI/CD?
GitHub Actions

### Monitoring?
Sentry error tracking, log aggregation

### Special infrastructure needs?
- Background job queue (scheduled post publishing, email sending, analytics aggregation)
- Email infrastructure (SendGrid/SES with domain verification, DKIM, SPF)
- Media storage (S3-compatible for images, videos)
- OAuth token management (refresh tokens for social platforms)
- Rate limiter per social platform (Twitter: 300 tweets/3hrs, LinkedIn: 100 posts/day)
- Webhook receivers (email events, social platform webhooks)
- Scheduled cron jobs (publish posts at scheduled times, send recurring campaigns, aggregate daily analytics)
