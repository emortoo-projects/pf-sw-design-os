# Business OS — SDOS Input Guide

> Use these answers when walking through the SDOS 9-stage pipeline to generate the Business OS SDP.

---

## Stage 1: Product Definition

### What are you building?

Business OS — the operational backbone for solo entrepreneurs and small teams inside BMHQ. It handles everything between "I have a lead" and "I got paid." CRM to track contacts and deals, invoicing to bill clients, proposals to win work, project tracking to deliver it, and a client portal so customers can see their status without emailing you. Think of it as HoneyBook + FreshBooks + a lightweight Notion for client work — unified in one module with AI assistance throughout. Every action feeds into the BMHQ dashboard and connects to other modules.

### Who is this for?

Solo entrepreneurs, freelancers, and small agencies (1-10 people) who run service-based businesses. They juggle client communication, project delivery, invoicing, and follow-ups across 5+ separate tools. They need one place to manage the entire client lifecycle — from first contact to final payment. They want AI to draft proposals, follow up on overdue invoices, and flag deals that are going cold.

### What problems does this solve?

1. Client information scattered across email, spreadsheets, and sticky notes — no single source of truth for contacts, deals, and history
2. Invoicing is manual and slow — creating invoices in one tool, tracking payments in another, chasing late payments by memory
3. Proposals take hours to write from scratch every time — no templates, no AI assistance, no reusable sections
4. No visibility into pipeline health — can't answer "how much revenue is coming next month?" without digging through spreadsheets
5. Clients constantly ask "what's the status?" — no self-service portal, every update requires an email
6. Project delivery is tracked in the founder's head — no shared timeline, no milestone tracking, easy to miss deadlines
7. Contractor management is a mess — tracking hours, payments, and deliverables across multiple freelancers manually

### What are the must-have features?

- **CRM & Pipeline**: Contact management with companies and people, deal pipeline with customizable stages (Lead → Qualified → Proposal → Negotiation → Won → Lost), activity timeline per contact, email integration, tags and filters, lead scoring
- **Invoicing & Billing**: Create professional invoices from templates, recurring invoices, payment tracking (paid/partial/overdue), payment reminders (automated), tax calculations, multi-currency support, payment link integration (Stripe), invoice PDF export
- **Proposals & Contracts**: AI-generated proposals from templates, drag-and-drop section builder, pricing tables with optional line items, e-signature integration, proposal analytics (opened, viewed, signed), convert won proposal to project automatically
- **Project Tracker**: Kanban board and list view for projects, milestones and deliverables, time tracking per task, budget tracking (hours used vs estimated), file attachments per project, link projects to deals and invoices
- **Client Portal**: Branded portal per client, view project status and timeline, access invoices and payment history, download shared files and deliverables, message thread with the business owner
- **Contractor Management**: Add contractors with rates and specialties, assign to projects, track hours and approve timesheets, generate contractor payments, 1099 tracking at year end
- **Documents**: Contract templates with variable fields, AI-generated scope of work documents, document library organized by client, version history

### What do people use today instead?

HoneyBook or Dubsado for proposals and contracts. FreshBooks or Wave for invoicing. Google Sheets or Notion for CRM and project tracking. Email for client communication. Separate tools for time tracking (Toggl, Harvest). Each tool has its own login, its own data, its own monthly fee. Nothing talks to each other.

### What makes yours different?

It's a unified module inside BMHQ — CRM, invoicing, proposals, projects, and client portal all share the same data. Win a deal → it auto-creates a project and first invoice. Complete a milestone → client portal updates and invoice triggers. AI assists everywhere: drafts proposals, writes follow-up emails, flags at-risk deals, generates scope documents. Connected to Agent OS for automation (auto-follow-up sequences), Marketing OS for lead capture, and Mission Control for monitoring.

### Any constraints or preferences?

Must follow the BMHQModule interface for integration into the BMHQ shell. React + Vite frontend (or Next.js matching BMHQ). Node.js/Express or tRPC backend. PostgreSQL shared with BMHQ platform. Stripe integration for payments. PDF generation for invoices and proposals. Dark theme matching BMHQ design system. Accent color: #F97316 (orange). Docker-first deployment.

---

## Stage 2: Data Model

### What are the main things your app tracks?

Contact, Company, Deal, DealStage, Activity, Invoice, InvoiceLineItem, Payment, Proposal, ProposalSection, Contract, Project, Milestone, Task, TimeEntry, ClientPortal, PortalMessage, Contractor, ContractorPayment, Document, Template, Tag, Pipeline

### How do these things relate to each other?

A Company has many Contacts. A Contact has many Deals. A Deal belongs to a Pipeline and has a DealStage. A Deal has many Activities (calls, emails, notes, meetings). A Deal can generate a Proposal. A Proposal has many ProposalSections and can become a Contract. A won Deal creates a Project. A Project has many Milestones, and Milestones have many Tasks. Tasks have TimeEntries. A Project generates Invoices. An Invoice has many InvoiceLineItems and receives Payments. A Client (Contact) has a ClientPortal with PortalMessages. Contractors are assigned to Projects and submit TimeEntries. Contractors receive ContractorPayments. Documents are attached to any entity (Deal, Project, Contact). Templates are reusable for Proposals, Invoices, and Contracts. Tags can be applied to Contacts, Deals, and Projects.

### What important details does each thing have?

- **Contact**: id, companyId, firstName, lastName, email, phone, title, source (referral/website/social/cold), status (lead/active/inactive), tags, notes, avatarUrl, lastContactedAt, createdAt
- **Company**: id, name, website, industry, size, address, phone, logo, notes
- **Deal**: id, contactId, pipelineId, stageId, title, value, currency, probability, expectedCloseDate, actualCloseDate, status (open/won/lost), lostReason, source, assignedTo, notes
- **Invoice**: id, projectId, contactId, number (auto-increment INV-001), status (draft/sent/viewed/paid/partial/overdue/cancelled), issueDate, dueDate, subtotal, taxRate, taxAmount, total, amountPaid, amountDue, currency, notes, paymentLink, pdfUrl, sentAt, paidAt, recurringConfig (JSONB)
- **Proposal**: id, dealId, contactId, title, status (draft/sent/viewed/accepted/rejected/expired), content (JSONB — sections), pricing (JSONB), validUntil, sentAt, viewedAt, acceptedAt, signatureUrl, pdfUrl
- **Project**: id, dealId, contactId, title, description, status (planning/active/on_hold/completed/cancelled), startDate, endDate, budget, budgetUsed, hourlyRate, estimatedHours, actualHours

### Any special data needs?

- Multi-currency support (USD, EUR, GBP, CAD)
- Recurring invoice schedules (weekly, monthly, quarterly, annually)
- Audit trail on all financial transactions
- Soft deletes on everything
- Full-text search across contacts, deals, projects
- File attachments (S3/local storage)

---

## Stage 3: Database

### Database preference?
PostgreSQL

### How much data?
Medium (hundreds of contacts, thousands of invoices over time, growing daily)

### Where will the database run?
Local Docker first, Railway/Supabase for production

---

## Stage 4: API Design

### What style of API?
REST with resource-based routes

### How should users authenticate?
Shared with BMHQ platform auth (JWT tokens, session management)

### Any external APIs or services to integrate?
- Stripe (payment processing, payment links, webhooks for payment events)
- SendGrid (invoice emails, proposal emails, reminder emails)
- Google OAuth (email integration for activity logging)
- DocuSign or HelloSign API (e-signature for contracts)
- S3-compatible storage (file uploads, invoice PDFs, proposal PDFs)

### Any special API requirements?
- Webhook endpoints for Stripe payment notifications
- PDF generation endpoint for invoices and proposals
- Bulk operations (bulk invoice send, bulk status update)
- Search endpoint with full-text search across entities
- Dashboard aggregation endpoint (pipeline value, revenue, overdue amounts)
- Rate limiting per organization

---

## Stage 5: Tech Stack

### Frontend preference?
React + Vite (matching BMHQ)

### Styling?
Tailwind CSS + shadcn/ui

### State management?
Zustand + TanStack Query

### Deployment?
Docker (local first)

---

## Stage 6: Design System

### What vibe?
Professional & clean with warm accents. Should feel trustworthy (you're handling money and client relationships).

### Brand colors?
Primary: #F97316 (orange — energy, action, warmth). Dark backgrounds from BMHQ shared design system. Success green for paid invoices, red for overdue, amber for pending.

### Apps to look like?
HoneyBook (proposals and client experience), Stripe Dashboard (invoicing and payments), Linear (project management), FreshBooks (clean invoicing)

### Layout structure?
Sidebar navigation within the BMHQ shell frame. Main content area with contextual panels.

### Dark mode?
Both (inherits from BMHQ platform toggle)

---

## Stage 7: Sections / Pages

### What are the main screens or pages?

1. **Dashboard** — Revenue this month, pipeline value, overdue invoices, upcoming milestones, recent activity feed, deal velocity chart, cash flow mini forecast
2. **Contacts** — Searchable table/grid of all contacts and companies, filter by tag/status/source, click to open contact detail with activity timeline, deals, invoices, projects
3. **Pipeline** — Visual kanban board of deals by stage, drag to move between stages, deal cards show value/contact/probability, pipeline summary bar (total value per stage)
4. **Invoices** — Table view of all invoices with status badges, filter by status/client/date, create new invoice with line item editor, preview PDF, send via email, record payment
5. **Proposals** — Grid of proposals with status, create new proposal with drag-and-drop section builder, AI generate sections, preview, send, track views
6. **Projects** — List/kanban of active projects, project detail with milestones, tasks, time entries, budget tracker, linked invoices
7. **Client Portal Admin** — Configure portal appearance, view what clients see, manage portal access per client
8. **Contractors** — List of contractors, assign to projects, review timesheets, process payments
9. **Documents** — File library organized by client/project, templates for reuse
10. **Reports** — Revenue by month/quarter, pipeline conversion rates, invoice aging, top clients by revenue, time utilization, profitability per project

### What's the first thing users see after login?

Dashboard showing: revenue collected this month vs last month, pipeline value breakdown by stage, overdue invoices requiring action (with "Send Reminder" button), upcoming milestones this week, recent activity feed (emails, payments, deal moves). If zero data, show onboarding: "Add your first contact" → "Create a deal" → "Send a proposal" → "Invoice your client."

### Any complex interactions?

- **Invoice builder**: Add/remove/reorder line items, auto-calculate subtotal/tax/total, preview PDF in real-time, payment link generation
- **Proposal builder**: Drag-and-drop sections (intro, scope, timeline, pricing, terms), AI fills each section from deal context, real-time preview, e-signature flow
- **Pipeline kanban**: Drag deals between stages, bulk actions on selected deals, click deal card to expand inline detail panel
- **Payment recording**: Partial payment support, payment method tracking, auto-status update (partial → paid when fully paid)
- **Time tracking**: Start/stop timer on tasks, manual entry, weekly timesheet view, approve contractor hours

### Which screens display a lot of data?

- **Contacts** — could be 500+ contacts, needs search, filters, pagination, virtual scrolling
- **Invoices** — years of invoice history, needs date range filters, status filters, export to CSV
- **Reports** — aggregated data with charts, needs date range selector, comparison periods
- **Activity timeline** — per-contact history of all interactions, infinite scroll

---

## Stage 8: Infrastructure

### Environments?
Local + Production

### CI/CD?
GitHub Actions

### Monitoring?
Sentry error tracking, log aggregation

### Special infrastructure needs?
- PDF generation service (for invoices and proposals)
- Email sending service (SendGrid)
- File storage (S3-compatible)
- Stripe webhook endpoint
- Scheduled jobs (recurring invoices, payment reminders, overdue alerts)
