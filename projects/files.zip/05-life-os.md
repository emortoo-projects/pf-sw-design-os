# Life OS — SDOS Input Guide

> Use these answers when walking through the SDOS 9-stage pipeline to generate the Life OS SDP.

---

## Stage 1: Product Definition

### What are you building?

Life OS — the personal operating system for the human behind the business, inside BMHQ. Solo founders optimize their business but neglect the rest of their life until burnout hits. Life OS tracks the whole person across six life areas: Health, Relationships, Finance (personal wellness view, not bookkeeping), Career, Education, and Spiritual/Mental. It's a daily planner, habit tracker, journal, goal setter, and personal dashboard — a NASA-style command center for your life. Morning planning, evening reflection, habit streaks, mood tracking, relationship maintenance, and wellness monitoring. Think Notion life dashboard + Habitica + Day One journal — unified with AI-powered insights and connected to the rest of BMHQ so your business metrics and life metrics live side by side.

### Who is this for?

Solo entrepreneurs who pour everything into their business and wake up one day wondering why they feel burned out, disconnected from friends, and haven't exercised in months. People who know they should journal, track habits, and maintain relationships but have no system. Founders who want to be intentional about their entire life, not just their revenue.

### What problems does this solve?

1. No system for life outside work — business has dashboards and KPIs, personal life has nothing
2. Habits start and stop — no accountability, no streaks, no visual progress
3. Relationships fade — forget to check in with friends, miss birthdays, drift from people who matter
4. Health is neglected — no tracking of exercise, sleep, nutrition, water intake
5. No daily reflection practice — days blur together without journaling, lessons are lost
6. Goals are vague and forgotten — "get healthier" and "read more" without specific targets or tracking
7. Mental health goes unmonitored — mood swings, stress patterns, and burnout signals aren't tracked until crisis
8. Life feels unbalanced — spending 80 hours on career, 0 on relationships, and having no visibility into that imbalance

### What are the must-have features?

- **Life Dashboard**: Overview of all 6 life areas with scores (1-10). Radar chart showing balance. Today's schedule, habits due, and priorities. Life Score trend over time. Quick capture buttons for mood, gratitude, and notes
- **Daily Planner**: Morning planning routine (top 3 priorities, intention, energy level). Time blocks for the day. Evening reflection (wins, lessons, gratitude). Energy management (mark high/low energy times). Tomorrow prep
- **Habit Tracker**: Define habits with frequency (daily, weekdays, 3x/week). Visual streak tracking (GitHub contribution graph style). Habit completion history. Habit stacking (group habits into routines). Reminders. Success rate per habit. Monthly habit reports
- **Health Dashboard**: Exercise log (type, duration, intensity). Sleep tracking (hours, quality 1-5). Nutrition tracking (simple — rate meals 1-5, not calorie counting). Water intake. Weight/body measurements. Mood correlation with health data
- **Journal**: Daily journal with AI prompts ("What are you grateful for?", "What challenged you today?", "What would you do differently?"). Rich text with photos. Mood rating per entry. Monthly and yearly reflection AI-generated summaries. Private and searchable
- **Goal Setting**: Goals across all 6 life areas. SMART framework with AI assistance. Quarterly reviews. Annual themes (word of the year). Goal breakdown into weekly actions. Progress visualization. Celebration when goals hit
- **Relationship Manager**: People list with relationship type (family, friend, mentor, professional). Last contact date. Contact frequency goal (weekly, monthly, quarterly). Birthday and anniversary reminders. Notes per person. "Reach out" queue showing overdue contacts
- **Mood Tracker**: Daily mood rating (1-5 or emoji scale). Optional journal note per mood entry. Mood trend chart. Correlation analysis (mood vs sleep, exercise, work hours). Flagging patterns (3+ low days triggers gentle prompt)
- **Life Score**: Composite score across all 6 areas. Each area scored 1-10 based on habit completion, goal progress, and self-assessment. Weekly self-rating prompt. Historical trend. Balance visualization (radar chart)

### What do people use today instead?

Notion templates for life dashboards. Habitica or Streaks for habits. Day One for journaling. Apple Health or Fitbit for health. Google Calendar for planning. Spreadsheets for goals. Contacts app for birthdays. No tool connects all of these into one coherent system.

### What makes yours different?

Everything about your life in one dashboard, scored and tracked over time. AI generates journal prompts based on your patterns, spots burnout signals, and creates monthly life reviews. The Life Score gives you a single number for how your life is going — like a credit score for your wellbeing. Connected to BMHQ so your work-life balance is visible — if Agent OS shows you worked 60 hours this week and Life OS shows your relationship score dropping, the system can flag it. No other tool connects business performance to personal wellbeing.

### Any constraints or preferences?

BMHQModule interface. React + Vite or Next.js. Tailwind + shadcn/ui. PostgreSQL. Accent color: #14B8A6 (teal — calm, balance, wellness). Warm and supportive tone in all UI copy. Privacy-first — life data is the most sensitive. No external sharing by default. Docker-first deployment.

---

## Stage 2: Data Model

### What are the main things your app tracks?

LifeArea, LifeScore, LifeScoreHistory, DailyPlan, DailyReflection, TimeBlock, Habit, HabitEntry, HabitStreak, Goal, GoalAction, GoalReview, JournalEntry, MoodEntry, HealthLog, ExerciseLog, SleepLog, WaterLog, Person, PersonInteraction, Birthday, Reminder, RoutineTemplate, WeeklyReview, MonthlyReview, AnnualTheme

### How do these things relate to each other?

LifeAreas are the 6 pillars (Health, Relationships, Finance, Career, Education, Spiritual/Mental). Each has a LifeScore that changes over time (LifeScoreHistory). DailyPlans hold the morning planning (priorities, intention, time blocks). DailyReflections capture the evening review. TimeBlocks structure the day. Habits are recurring behaviors tracked with HabitEntries (completion per day) and HabitStreaks. Goals belong to LifeAreas and have GoalActions (weekly breakdown) and GoalReviews (quarterly check-ins). JournalEntries are daily writings with optional prompts. MoodEntries track emotional state. HealthLogs are the parent for ExerciseLogs, SleepLogs, and WaterLogs. Persons are people in your life with PersonInteractions tracking contact. Birthdays and Reminders handle key dates. RoutineTemplates define reusable habit stacks (morning routine, evening routine). WeeklyReviews and MonthlyReviews are AI-assisted life reviews.

### What important details does each thing have?

- **LifeArea**: id, name (health/relationships/finance/career/education/spiritual), icon, color, currentScore (1-10), description
- **LifeScore**: id, date, overallScore (float), areaScores (JSONB — {health: 7, relationships: 6, ...}), selfAssessed (boolean), notes
- **DailyPlan**: id, date, intention, energyLevel (1-5), topPriorities (JSONB array of 3), timeBlocks (JSONB), notes, completionRate
- **Habit**: id, name, description, frequency (daily/weekdays/weekly/custom), customDays (JSONB), lifeAreaId, icon, color, currentStreak, longestStreak, isActive, createdAt, archivedAt, reminderTime, routineId
- **HabitEntry**: id, habitId, date, completed (boolean), skipped (boolean), notes
- **Goal**: id, lifeAreaId, title, description, targetMetric, currentMetric, unit, startDate, endDate, status (active/completed/abandoned/paused), smartBreakdown (JSONB — specific, measurable, achievable, relevant, timeBound)
- **JournalEntry**: id, date, content (rich text JSON), mood (1-5), gratitude (JSONB array), prompts (JSONB — question:answer pairs), tags, isPrivate, weatherEmoji
- **MoodEntry**: id, date, time, mood (1-5), emoji, energy (1-5), notes, factors (JSONB — tags like "good sleep", "stressful meeting", "exercise")
- **Person**: id, name, relationship (family/friend/mentor/colleague/professional), contactFrequency (weekly/biweekly/monthly/quarterly), lastContactDate, birthday, email, phone, notes, photoUrl, importance (1-5)
- **ExerciseLog**: id, date, type (running/weights/yoga/walking/cycling/swimming/other), durationMinutes, intensity (1-5), notes, caloriesBurned
- **SleepLog**: id, date, bedtime, wakeTime, hoursSlept (float), quality (1-5), notes

### Any special data needs?

- Time-series data for all tracking (mood, habits, health, scores) — optimized for trend queries
- JSONB for flexible structured data (daily priorities, mood factors, goal breakdowns)
- Full-text search across journal entries
- Date-based queries are critical (everything is organized by day)
- Soft deletes (journal entries and personal data should never hard delete)
- Encryption at rest for journal entries and mood data (most sensitive personal data in the system)
- Export capability (users should be able to export all their life data)

---

## Stage 3: Database

### Database preference?
PostgreSQL

### How much data?
Medium (daily entries across all tracking types, grows linearly over years)

### Where will the database run?
Local Docker first, production on Railway/Supabase

---

## Stage 4: API Design

### What style of API?
REST

### How should users authenticate?
Shared with BMHQ platform auth

### Any external APIs or services to integrate?
- OpenAI/Anthropic API (journal prompts, weekly/monthly AI reviews, mood pattern analysis — shared via BMHQ AI config)
- Calendar API (optional — sync time blocks with Google Calendar)
- Weather API (optional — correlate mood with weather)
- No health device APIs in v1 (manual entry only — keeps it simple and private)

### Any special API requirements?
- Daily summary endpoint (aggregate all tracking for a given day — plan, habits, mood, health, journal)
- Streak calculation endpoint (current and longest streak per habit)
- Life Score calculation endpoint (composite score from habits, goals, self-assessment)
- AI journal prompt endpoint (generate contextual prompts based on recent entries and patterns)
- AI review generation endpoint (weekly and monthly life reviews from data)
- Mood analysis endpoint (trends, correlations, pattern detection)
- Contact reminder endpoint (people overdue for check-in based on frequency)
- Data export endpoint (full export of all personal data as JSON/CSV)
- Birthday/reminder notification endpoint

---

## Stage 5: Tech Stack

### Frontend preference?
React + Vite (matching BMHQ)

### Styling?
Tailwind CSS + shadcn/ui

### Charts?
Recharts (for mood trends, habit heatmaps, life score radar)

### State management?
Zustand + TanStack Query

### Deployment?
Docker (local first)

---

## Stage 6: Design System

### What vibe?
Warm, calm, supportive, personal. Should feel like a cozy journal app, not a productivity tool. Soft edges, gentle colors, encouraging language. Celebrate streaks and wins. Never judgmental about missed habits or low moods.

### Brand colors?
Primary: #14B8A6 (teal — calm, balance). Warm accent: #F59E0B (amber — for streaks, celebrations). Soft pastels for life areas: Health=#10B981 green, Relationships=#EC4899 pink, Finance=#F59E0B amber, Career=#6366F1 indigo, Education=#8B5CF6 violet, Spiritual=#14B8A6 teal. Mood colors: great=#22C55E, good=#84CC16, okay=#F59E0B, low=#F97316, rough=#EF4444.

### Apps to look like?
Notion (clean dashboard), Day One (beautiful journaling), Streaks (habit visualization), Apple Health (data presentation), Headspace (calm and supportive feeling), Daylio (mood tracking simplicity)

### Layout structure?
Sidebar navigation within BMHQ shell. Daily view is the primary paradigm (what's happening today). Calendar underlays everything. Full-screen focus mode for journaling and planning.

### Dark mode?
Both (inherits from BMHQ platform toggle)

---

## Stage 7: Sections / Pages

### What are the main screens or pages?

1. **Life Dashboard** — Life Score radar chart (6 areas), today's habit completion progress ring, current streak count, mood trend (last 7 days), upcoming birthdays/reminders, "How are you feeling?" quick mood entry, today's priorities (from Daily Plan), motivational quote or AI insight
2. **Daily View** — Morning section: set intention, pick top 3 priorities, rate energy level, plan time blocks. Daytime section: habit checklist, running notes, mood check-in. Evening section: reflection prompts (wins, lessons, gratitude), rate the day. Swipe between days
3. **Habits** — Habit list with today's status (done/not done). GitHub-style contribution heatmap per habit. Streak leaderboard (your habits ranked by current streak). Add/edit habits. Routine builder (group habits into morning/evening routines). Weekly/monthly completion rates
4. **Journal** — Calendar view showing days with entries (dot indicator). Today's entry editor with AI prompts. Rich text with photo support. Tag entries. Search across all entries. Monthly AI-generated reflection. Gratitude list view
5. **Goals** — Goals grouped by life area. Progress bars per goal. Goal detail: SMART breakdown, weekly actions, milestone timeline. Quarterly review prompt. Create goal with AI assistance (turn vague goal into SMART goal). Completed goals archive
6. **Health** — Exercise log with weekly summary chart. Sleep tracker with quality trend. Water intake daily tracker. Meal quality tracker (simple 1-5 rating). Weight/measurements chart. AI insights ("Your mood is 40% better on days you exercise")
7. **People** — Card grid of important people with last contact date and status (overdue/due soon/good). Click to see interaction history and notes. "Reach out" queue prioritized by most overdue. Birthday calendar view. Add interaction (call, text, coffee, email) with notes
8. **Mood** — Mood calendar (color-coded by daily mood). Mood trend line chart. Factor analysis (what correlates with good/bad days). Weekly mood summary. Log mood entry with emoji, energy level, and contributing factors
9. **Reviews** — Weekly review template (wins, challenges, lessons, next week priorities). Monthly review template (life area scores, habit stats, goal progress, AI-generated insights). Annual review (themes, achievements, growth areas). All reviews stored and searchable
10. **Settings** — Life area customization (rename, recolor, reorder). Habit reminder times. Journal prompt preferences. Privacy settings (which data to share with BMHQ dashboard). Data export. Notification preferences

### What's the first thing users see after login?

Life Dashboard showing: Life Score radar chart front and center (how balanced is your life right now?), today's habit progress ring (5/8 habits done), current longest streak with flame icon, mood trend sparkline for the last 7 days, today's top 3 priorities (from morning plan or "Plan your day" prompt), upcoming birthdays this week, and a gentle AI insight ("You tend to feel best on days you journal — you haven't written in 3 days"). If zero data: warm onboarding — "Welcome to Life OS. Let's set up your life areas." → Pick which areas matter most → Add 3 starter habits → Set one goal → Write your first journal entry.

### Any complex interactions?

- **Daily Planning Flow**: Morning planning is a guided sequence — set intention → pick priorities → rate energy → optionally set time blocks. Should feel meditative and intentional, not like filling out a form. Animated transitions between sections
- **Habit Heatmap**: GitHub-style contribution calendar showing habit completion over months. Hover to see details. Different colors for different completion rates. Scrollable over years
- **Life Score Radar Chart**: Interactive radar chart where you can click each axis to self-assess (drag the point to set your score). Animated transitions. Compare current vs last month
- **Journal with AI Prompts**: AI generates 3 contextual prompts based on your recent data ("You hit your exercise goal 5 days this week — how does that feel?", "You haven't talked to [person] in 45 days — what's going on?"). Prompts are suggestions, not requirements
- **Mood Correlation Analysis**: AI analyzes mood entries against habit completion, sleep, exercise, and work hours (from Agent OS/Mission Control) to find patterns. Presents insights as cards: "Your mood improves 35% on days with 7+ hours of sleep"
- **Relationship Check-in Queue**: Sorted list of people overdue for contact. One-tap to log an interaction. Suggest conversation starters based on last interaction notes. After logging, next person appears

### Which screens display a lot of data?

- **Habit Heatmap** — 365 days × multiple habits, needs efficient rendering
- **Journal Archive** — years of daily entries, needs date navigation, search, and lazy loading
- **Mood History** — daily entries over years, needs aggregation views (weekly/monthly averages)
- **Health Trends** — multiple tracking types (exercise, sleep, water, nutrition) with daily data points over months
- **Reviews** — accumulated weekly/monthly reviews over years, needs date range browsing

---

## Stage 8: Infrastructure

### Environments?
Local + Production

### CI/CD?
GitHub Actions

### Monitoring?
Sentry error tracking, log aggregation

### Special infrastructure needs?
- Encryption at rest for all personal data (journal entries, mood data, health data)
- Scheduled jobs (morning planning notification, evening reflection reminder, birthday alerts, streak calculation, contact overdue check)
- AI integration for journal prompts, weekly reviews, mood analysis, goal coaching
- Data export service (GDPR-style full data export as JSON)
- Photo storage for journal entries (S3-compatible)
- Push notification support (habit reminders, birthday alerts, review prompts)
