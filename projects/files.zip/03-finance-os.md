# Finance OS — SDOS Input Guide

> Use these answers when walking through the SDOS 9-stage pipeline to generate the Finance OS SDP.

---

## Stage 1: Product Definition

### What are you building?

Finance OS — the personal and business money management module inside BMHQ. It answers the two questions every solo founder asks daily: "Where did my money go?" and "Can I afford this?" It tracks income and expenses across business and personal accounts, generates profit & loss statements, estimates quarterly taxes, forecasts cash flow, and keeps everything organized for your accountant. Think QuickBooks simplicity meets Mint personal finance — unified in one module with AI-powered categorization and insights. It connects to Business OS (invoices paid = income recorded) and provides the financial layer for the entire BMHQ platform.

### Who is this for?

Solo entrepreneurs and freelancers who mix business and personal finances, hate bookkeeping, and only think about taxes in April. They need a system that automatically categorizes transactions, separates business from personal spending, tracks estimated quarterly taxes, and generates reports their accountant can use. They want AI to flag unusual expenses, predict cash flow problems before they happen, and tell them if they can afford to hire their first employee.

### What problems does this solve?

1. No separation between business and personal finances — money flows between accounts with no clear tracking of what's deductible and what's personal
2. Bookkeeping doesn't happen until tax time — then it's a scramble through 12 months of bank statements
3. Quarterly estimated taxes are guesswork — either overpaying (losing cash flow) or underpaying (penalties)
4. No cash flow visibility — can't answer "will I have enough to cover payroll next month?" without manual spreadsheet work
5. Receipts are lost — paper receipts fade, digital receipts buried in email, no organized system for expense documentation
6. Multiple income streams are hard to track — consulting, products, services, passive income all flowing into different accounts
7. Financial reports for loans or investors require hours of manual preparation
8. No connection between invoicing (Business OS) and actual revenue tracking — invoiced vs collected are tracked in different systems

### What are the must-have features?

- **Transaction Tracker**: Manual entry and bank import (CSV/OFX). AI-powered auto-categorization. Business vs personal tagging. Split transactions (partially business, partially personal). Recurring transaction detection. Receipt photo capture and attachment. Search and filter by date, category, account, amount
- **Account Management**: Multiple accounts (checking, savings, credit cards, PayPal, Stripe). Account balances and reconciliation. Transfer tracking between accounts. Business and personal account separation
- **Income Tracking**: Revenue by client (linked to Business OS invoices). Revenue by service/product type. Monthly/quarterly/annual revenue views. Income stream breakdown. Recurring revenue tracking (MRR for subscription-based work)
- **Expense Management**: Categorized expenses (IRS Schedule C categories for US). Mileage tracking (for New Day Learning transportation). Home office deduction calculator. Subscription tracker (all recurring charges with renewal dates). Expense approval workflow (for team use)
- **Profit & Loss**: Real-time P&L statement. Monthly, quarterly, annual views. Compare periods (this month vs last month, this quarter vs same quarter last year). Gross margin, net margin, operating expenses breakdown. Export to PDF/CSV
- **Tax Preparation**: Estimated quarterly tax calculator (federal + state). Track estimated payments made. Deduction tracker with categories. Tax-ready reports for accountant. 1099 tracking for contractors (linked to Business OS). Year-end summary with all tax-relevant totals
- **Cash Flow Forecaster**: 30/60/90 day cash flow projection. Known upcoming income (scheduled invoices from Business OS). Known upcoming expenses (recurring bills, contractor payments). Scenario planning ("what if I hire at $5K/month?"). Runway calculator ("how many months can I operate at current burn rate?")
- **Budget Planner**: Monthly budgets by category. Budget vs actual comparison. Alerts when approaching or exceeding budget. Savings goals with progress tracking. Annual budget planning
- **Reports & Export**: P&L statement, balance sheet summary, expense report, income report, tax summary. Export to PDF, CSV, Excel. Accountant-ready package (annual zip with all reports). Custom date ranges. Chart visualizations

### What do people use today instead?

QuickBooks Self-Employed or Wave for bookkeeping. Mint or YNAB for personal budgeting. Spreadsheets for cash flow forecasting. Shoebox or Expensify for receipt tracking. TurboTax for tax estimation. Their accountant's portal for tax prep. Each tool sees only part of the picture.

### What makes yours different?

Unified business + personal view — see your complete financial picture, not just the business side. AI categorizes transactions and flags anomalies automatically. Direct connection to Business OS means invoices and payments flow in without double entry. Cash flow forecasting uses real data from scheduled invoices and known recurring expenses. Tax estimation updates in real-time as income and expenses change. Inside BMHQ, Agent OS can automate receipt categorization and send weekly financial summaries.

### Any constraints or preferences?

BMHQModule interface. React + Vite or Next.js. Tailwind + shadcn/ui. PostgreSQL. Accent color: #10B981 (emerald green — money, growth, stability). CSV/OFX import for bank transactions (no direct bank API integration in v1 — too complex with Plaid). PDF generation for reports. Docker-first deployment. All financial calculations must be precise (use integer cents, not floating point dollars).

---

## Stage 2: Data Model

### What are the main things your app tracks?

Account, Transaction, TransactionCategory, TransactionSplit, TransactionAttachment, RecurringTransaction, Budget, BudgetItem, IncomeStream, TaxEstimate, TaxPayment, TaxDeduction, Invoice (read from Business OS), MileageLog, Subscription, CashFlowForecast, ForecastScenario, FinancialReport, Goal, GoalContribution

### How do these things relate to each other?

An Account has many Transactions. A Transaction belongs to a TransactionCategory and may have TransactionSplits (split across categories). Transactions can have TransactionAttachments (receipts). RecurringTransactions auto-generate Transactions on schedule. Budgets have BudgetItems per category with monthly limits. IncomeStreams group revenue by source (client, product, service type). TaxEstimates are quarterly calculations based on year-to-date income and expenses. TaxPayments track estimated payments made. TaxDeductions are specific deductible items with documentation. MileageLogs track business driving (important for New Day Learning). Subscriptions are tracked recurring expenses with renewal alerts. CashFlowForecasts project future balances using known income and expenses. ForecastScenarios are "what if" variations. Goals track savings targets with GoalContributions.

### What important details does each thing have?

- **Account**: id, name, type (checking/savings/credit_card/paypal/stripe/cash), institution, accountNumber (last 4 only), currency, currentBalance, isBusinessAccount (boolean), color, icon, isActive
- **Transaction**: id, accountId, categoryId, date, description, amount (integer cents), type (income/expense/transfer), isBusinessExpense (boolean), isTaxDeductible (boolean), notes, receiptUrl, reconciled (boolean), recurringTransactionId, businessOsInvoiceId, aiCategorized (boolean), aiConfidence (float)
- **TransactionCategory**: id, name, type (income/expense), parentCategoryId, irsCategory (Schedule C line number), icon, color, isDefault
- **Budget**: id, name, month, year, totalBudget (cents), status (active/closed)
- **BudgetItem**: id, budgetId, categoryId, plannedAmount (cents), actualAmount (cents)
- **TaxEstimate**: id, year, quarter (1-4), estimatedIncome (cents), estimatedExpenses (cents), estimatedTaxableIncome (cents), federalTaxRate, stateTaxRate, federalTaxDue (cents), stateTaxDue (cents), totalDue (cents), dueDate
- **MileageLog**: id, date, startLocation, endLocation, miles (float), purpose, businessOsProjectId, rate (IRS standard rate in cents)
- **Subscription**: id, name, amount (cents), frequency (monthly/quarterly/annual), nextRenewalDate, category, isBusinessExpense, autoRenew, cancelUrl, notes

### Any special data needs?

- All monetary values stored as integer cents (no floating point)
- Multi-currency support with exchange rate tracking
- IRS Schedule C category mapping for US tax reporting
- Year-over-year comparison data
- Time-series data for charts and trends
- Receipt image storage (S3-compatible)
- Audit trail on all financial data modifications
- Soft deletes on everything (financial records should never hard delete)

---

## Stage 3: Database

### Database preference?
PostgreSQL

### How much data?
Medium (thousands of transactions per year, growing steadily)

### Where will the database run?
Local Docker first, production on Railway/Supabase

---

## Stage 4: API Design

### What style of API?
REST

### How should users authenticate?
Shared with BMHQ platform auth

### Any external APIs or services to integrate?
- Business OS internal API (read invoices, payments, contractor payments)
- IRS mileage rate API or manual config (standard mileage rate updates annually)
- Exchange rate API (for multi-currency — Open Exchange Rates or similar)
- S3-compatible storage (receipt uploads)
- PDF generation (for financial reports)

### Any special API requirements?

- CSV/OFX file upload endpoint for bank transaction import
- AI categorization endpoint (classify uncategorized transactions)
- Aggregation endpoints (monthly totals, category breakdowns, year-to-date summaries)
- Tax calculation endpoint (compute estimated taxes based on YTD data)
- Cash flow projection endpoint (forecast based on known future income/expenses)
- Report generation endpoint (create PDF/CSV reports for any date range)
- Dashboard summary endpoint (key financial metrics in one call)
- Bulk transaction operations (categorize multiple, reconcile multiple)

---

## Stage 5: Tech Stack

### Frontend preference?
React + Vite (matching BMHQ)

### Styling?
Tailwind CSS + shadcn/ui

### Charts?
Recharts (already used in BMHQ ecosystem)

### State management?
Zustand + TanStack Query

### Deployment?
Docker (local first)

---

## Stage 6: Design System

### What vibe?
Clean, trustworthy, and precise. Numbers should be prominent and scannable. Green for income, red for expenses — universal financial language.

### Brand colors?
Primary: #10B981 (emerald green — money, growth). Red #EF4444 for expenses/overdue. Amber #F59E0B for warnings/approaching limits. Dark backgrounds from BMHQ shared system.

### Apps to look like?
Mint (personal finance dashboard), Wave (simple bookkeeping), Stripe Dashboard (clean financial data), Mercury (modern bank dashboard), YNAB (budget visualization)

### Layout structure?
Sidebar navigation within BMHQ shell. Dashboard-heavy with large number displays. Tables for transaction lists. Charts for trends and comparisons.

### Dark mode?
Both (inherits from BMHQ platform toggle)

---

## Stage 7: Sections / Pages

### What are the main screens or pages?

1. **Dashboard** — Net income this month, total revenue, total expenses, cash on hand across all accounts, P&L mini chart (6 months), budget status bars, upcoming bills, tax estimate status, cash flow forecast sparkline
2. **Transactions** — Searchable/filterable table of all transactions. Columns: date, description, category, account, amount, business/personal tag, receipt icon. Inline category editing. Bulk actions (categorize, tag as business). Import button for CSV/OFX upload
3. **Accounts** — Card view of all accounts with current balances. Total net worth summary. Click account to see its transactions. Add/edit accounts. Reconciliation tool
4. **Income** — Revenue dashboard: total by month chart, by client breakdown (linked to Business OS), by service type, by income stream. Recurring revenue (MRR) tracker. Year-over-year comparison
5. **Expenses** — Expense dashboard: total by month chart, by category pie chart, top expense categories, largest individual expenses. Subscription tracker with renewal dates and "cancel" links. Mileage log with totals
6. **Budgets** — Monthly budget setup with category limits. Budget vs actual bars per category. Overall budget health (on track / over budget). Historical budget performance. Create/edit budget templates
7. **Tax Center** — Year-to-date income and expenses. Estimated quarterly tax calculation (federal + state). Payment tracker (estimated payments made). Deduction list with totals. 1099 contractor summary. Tax timeline (due dates with alerts). Year-end tax package generator
8. **Cash Flow** — 30/60/90 day projection chart. Known upcoming income (from Business OS scheduled invoices). Known upcoming expenses (recurring bills). Scenario builder ("what if I hire at $X/month?"). Runway calculator. Burn rate trend
9. **Reports** — Report generator: select type (P&L, expense report, income report, tax summary), date range, filters. Preview before export. Export to PDF/CSV/Excel. Saved report templates. Accountant package (zip all reports for a year)
10. **Mileage** — Mileage log with date, from/to, miles, purpose. Linked to Business OS projects. IRS rate calculator. Monthly/annual mileage totals. Export for tax purposes

### What's the first thing users see after login?

Dashboard showing: net income this month (big number, green if positive, red if negative), revenue vs expenses bar chart (last 6 months), account balances across all accounts, budget status (% used this month), next estimated tax payment due (amount and date), upcoming recurring expenses this week, quick action buttons: "Add Transaction", "Log Mileage", "Import Bank Statement." If zero data: "Connect your finances" onboarding — "Add your first account" → "Import transactions" → "Set up your budget."

### Any complex interactions?

- **Bank Import**: Upload CSV/OFX → parse and preview transactions → AI auto-categorizes each → user reviews and confirms → bulk import into system. Support for multiple bank formats
- **Transaction Splitting**: Click a transaction → split across multiple categories (e.g., $100 purchase = $60 business supplies + $40 personal). Each split gets its own category and business/personal tag
- **Tax Estimation**: Real-time calculation as income/expenses change. Shows federal + state breakdown. "What if" slider — "if I earn $X more this quarter, my estimated tax becomes $Y." Compares to payments already made
- **Cash Flow Forecasting**: Interactive chart where you can add hypothetical future income or expenses. Toggle scenarios on/off to compare. Drag income/expense bars to adjust timing
- **Budget Builder**: Category list with monthly limit input for each. Visual bar fills as expenses come in. Click category to see contributing transactions. Rollover unused budget (optional)
- **Receipt Capture**: Upload photo → AI extracts amount, date, vendor, category → creates transaction automatically

### Which screens display a lot of data?

- **Transactions** — years of transaction history, needs date range filters, category filters, account filters, search, pagination
- **Reports** — generated reports with hundreds of line items, needs export over display
- **Mileage Log** — daily entries for transportation business, needs month/project grouping
- **Income breakdown** — data aggregated from Business OS invoices + manual entries, needs efficient joins

---

## Stage 8: Infrastructure

### Environments?
Local + Production

### CI/CD?
GitHub Actions

### Monitoring?
Sentry error tracking, log aggregation

### Special infrastructure needs?
- PDF generation service (for financial reports and tax summaries)
- Receipt image storage (S3-compatible)
- CSV/OFX file parsing service
- Scheduled jobs (recurring transaction generation, budget period closing, tax estimate recalculation)
- Data encryption at rest for financial data
- Backup strategy (financial data is critical — daily backups)
