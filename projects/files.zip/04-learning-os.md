# Learning OS — SDOS Input Guide

> Use these answers when walking through the SDOS 9-stage pipeline to generate the Learning OS SDP.

---

## Stage 1: Product Definition

### What are you building?

Learning OS — the personal skill development and knowledge management module inside BMHQ. Solo founders who stop learning get outpaced. This module turns learning from random YouTube binges into a structured system. Track what you're learning, take AI-enhanced notes, build a personal knowledge base, use spaced repetition to actually remember things, and set quarterly skill goals with accountability. It's Readwise + Anki + Notion (for learning) + Coursera tracker — unified in one module with AI as your study partner. Ask questions about anything you've read or noted, and AI answers from your own knowledge base.

### Who is this for?

Solo entrepreneurs and knowledge workers who learn constantly but retain poorly. They read books, take courses, watch tutorials, and attend conferences — but six months later can't remember the key insights. They have highlights scattered across Kindle, notes in random docs, bookmarks they never revisit, and courses they started but never finished. They want a system that captures everything they learn and makes it retrievable and retainable.

### What problems does this solve?

1. Learning is unstructured — no plan for what skills to develop, just following whatever looks interesting that day
2. Notes are scattered everywhere — Notion, Google Docs, Apple Notes, physical notebooks, never unified
3. Reading highlights disappear — Kindle highlights and article saves are never revisited or synthesized
4. Course completion rates are low — start many courses, finish few, no tracking of actual progress
5. Knowledge decays — read a great book 3 months ago, can't recall the key frameworks or insights
6. No way to query your own knowledge — "what did I learn about pricing strategies?" requires manually searching through dozens of notes
7. Certifications and CPE credits are tracked in spreadsheets or not at all
8. No accountability for learning goals — easy to deprioritize learning when business gets busy

### What are the must-have features?

- **Learning Dashboard**: Current learning streak, skills in progress, recently reviewed, upcoming reviews (spaced repetition), weekly learning time, goal progress
- **Skill Tracker**: Define skills you're developing (e.g., "React", "Marketing", "Public Speaking"). Rate current proficiency (1-5). Set target proficiency. Track progress through courses, books, and practice. Visual skill map showing all skills and levels
- **Course Library**: Add courses from any platform (Udemy, Coursera, YouTube, etc). Track progress (% complete). Notes per course section. Certificate upload when completed. Rate and review courses. AI-generated summary when you finish
- **Reading List**: Add books, articles, papers, podcasts. Status tracking (want to read, reading, completed). Highlight capture (manual paste or API integration). Notes and takeaways per item. AI-generated book summaries from your highlights. Tag by skill/topic
- **Note System**: Rich text notes organized by topic, skill, or source. Bi-directional linking between notes (wiki-style). AI-enhanced search across all notes. Templates for different note types (book notes, course notes, meeting learnings, experiment results). Daily learning journal
- **AI Study Partner**: Ask questions about anything in your knowledge base. AI answers using your notes, highlights, and course content. "Quiz me on [topic]" generates questions from your material. "Explain [concept] simply" using your own context. "What have I learned about [topic]?" synthesizes across all sources
- **Spaced Repetition**: Create flashcards from notes (manually or AI-generated). SM-2 algorithm for optimal review scheduling. Daily review queue. Track retention rate per topic. Import/export Anki decks
- **Certifications**: Track professional certifications with expiry dates. CPE/CEU credit tracking. Renewal reminders. Upload certificate documents. Link to relevant courses
- **Learning Goals**: Quarterly and annual learning goals. SMART goal framework (Specific, Measurable, Achievable, Relevant, Time-bound). Progress tracking with milestones. Weekly check-in prompts. Streak tracking for daily learning habits

### What do people use today instead?

Notion for notes and learning tracking. Readwise for highlights. Anki for spaced repetition. Goodreads for reading lists. Spreadsheets for course tracking. Bookmarks for articles. Each tool captures one piece of the learning puzzle but none connect them.

### What makes yours different?

Everything you learn is in one place and AI-searchable. Take notes on a book → AI creates flashcards → spaced repetition ensures you remember → link notes to skills you're building → track progress toward goals. The AI study partner means your knowledge base is alive — you can have a conversation with everything you've ever learned. Inside BMHQ, Agent OS can automate daily review reminders, and Mission Control shows your learning metrics alongside business metrics.

### Any constraints or preferences?

BMHQModule interface. React + Vite or Next.js. Tailwind + shadcn/ui. PostgreSQL. Accent color: #8B5CF6 (violet — wisdom, knowledge, growth). Rich text editor for notes (TipTap). Markdown support. Full-text search with vector embeddings for semantic search. Docker-first deployment.

---

## Stage 2: Data Model

### What are the main things your app tracks?

Skill, SkillLevel, Course, CourseSection, CourseProgress, Book, BookHighlight, Article, Note, NoteLink, Tag, Flashcard, FlashcardDeck, FlashcardReview, Certification, CertificationCredit, LearningGoal, GoalMilestone, LearningSession, LearningStreak, DailyJournal

### How do these things relate to each other?

Skills are the top-level organizing concept. A Skill has SkillLevels (proficiency over time). Courses, Books, and Articles are learning resources linked to Skills via Tags. A Course has CourseSections and tracks CourseProgress. A Book has BookHighlights. Notes can be linked to any resource (course, book, article) or standalone. NoteLinks create bi-directional connections between Notes. Flashcards belong to FlashcardDecks and track FlashcardReviews (spaced repetition history). Flashcards can be auto-generated from Notes. Certifications track credentials with CertificationCredits. LearningGoals have GoalMilestones. LearningSessions track time spent learning. LearningStreaks track daily consistency. DailyJournals capture daily learning reflections.

### What important details does each thing have?

- **Skill**: id, name, category, currentLevel (1-5), targetLevel, description, icon, color, relatedSkillIds, createdAt
- **Course**: id, title, platform (udemy/coursera/youtube/other), url, instructor, totalSections, completedSections, status (not_started/in_progress/completed/abandoned), rating, startedAt, completedAt, certificateUrl, notes, skillIds
- **Book**: id, title, author, isbn, coverUrl, status (want_to_read/reading/completed), rating, startedAt, completedAt, pageCount, currentPage, notes, skillIds
- **Note**: id, title, content (rich text JSON), sourceType (course/book/article/standalone/journal), sourceId, tags, isPublic, embedding (vector for semantic search), createdAt, updatedAt
- **Flashcard**: id, deckId, front, back, noteId (source note), ease (SM-2 ease factor), interval (days until next review), dueDate, reviewCount, lapseCount
- **FlashcardReview**: id, flashcardId, rating (again/hard/good/easy), reviewedAt, responseTimeMs
- **LearningGoal**: id, title, description, type (quarterly/annual), skillId, targetMetric, currentMetric, startDate, endDate, status (active/completed/abandoned)
- **LearningSession**: id, skillId, resourceType, resourceId, durationMinutes, notes, date
- **DailyJournal**: id, date, content (rich text), keyInsight, mood (1-5), learningTimeMinutes

### Any special data needs?

- Vector embeddings for semantic search across notes (pgvector)
- Rich text content storage (TipTap JSON)
- Full-text search across all content (notes, highlights, course notes)
- Spaced repetition algorithm state (SM-2 parameters per flashcard)
- Time-series data for learning streaks and session tracking
- File uploads for certificates and book covers
- Bi-directional note linking (graph structure)

---

## Stage 3: Database

### Database preference?
PostgreSQL with pgvector extension (for semantic search embeddings)

### How much data?
Medium (hundreds of notes, thousands of flashcards, growing over years)

### Where will the database run?
Local Docker first, production on Railway/Supabase

---

## Stage 4: API Design

### What style of API?
REST

### How should users authenticate?
Shared with BMHQ platform auth

### Any external APIs or services to integrate?
- OpenAI/Anthropic API (AI study partner, flashcard generation, content summarization — shared via BMHQ AI config)
- Embedding API (for vector search — OpenAI embeddings or local model)
- Google Books API (book metadata lookup by ISBN/title)
- Open Library API (fallback for book metadata)
- S3-compatible storage (certificate uploads, book covers)

### Any special API requirements?
- Semantic search endpoint (query notes by meaning, not just keywords)
- AI chat endpoint (conversational AI study partner with knowledge base context)
- Flashcard generation endpoint (AI creates cards from a note)
- Spaced repetition endpoint (get today's review queue, submit review results)
- Learning analytics endpoints (time spent, streak data, skill progress)
- Note linking endpoint (create/remove bi-directional links)
- Import endpoints (Anki deck import, Readwise highlight import, Markdown note import)

---

## Stage 5: Tech Stack

### Frontend preference?
React + Vite (matching BMHQ)

### Styling?
Tailwind CSS + shadcn/ui

### Rich text editor?
TipTap (for note editor)

### State management?
Zustand + TanStack Query

### Deployment?
Docker (local first, with pgvector extension)

---

## Stage 6: Design System

### What vibe?
Calm, focused, intellectual. Should feel like a premium note-taking app meets a personal library. Plenty of whitespace for reading. Warm and inviting, not clinical.

### Brand colors?
Primary: #8B5CF6 (violet — wisdom, knowledge). Accent: #F59E0B (amber — for streaks, achievements). Skill levels: gradient from gray (beginner) to violet (expert). Success green for completed, blue for in progress.

### Apps to look like?
Notion (clean note-taking), Readwise Reader (reading experience), Anki (spaced repetition simplicity), Obsidian (note linking and knowledge graph), Duolingo (gamification and streaks)

### Layout structure?
Sidebar navigation within BMHQ shell. Note editor takes full width when active. Split view for reading + notes side by side. Flashcard review is a focused full-screen mode.

### Dark mode?
Both (inherits from BMHQ platform toggle)

---

## Stage 7: Sections / Pages

### What are the main screens or pages?

1. **Dashboard** — Learning streak (flame icon with day count), today's review queue (flashcards due), skills radar chart, recently active courses/books, weekly learning time chart, current learning goals with progress bars, "Quick Capture" note button
2. **Skills Map** — Visual grid or radar of all skills with proficiency levels. Click skill to see related courses, books, notes, goals. Add new skills. Set target levels. Progress timeline per skill
3. **Library** — Tabbed view: Courses | Books | Articles | All. Card grid with cover images, progress bars, status badges. Filter by skill, status, rating. Sort by recently active, rating, date added. Search across all resources
4. **Notes** — Two-panel layout: left sidebar with note tree (folders/tags), right panel with rich text editor. Bi-directional link suggestions as you type. Backlinks panel showing what links to current note. AI actions: summarize, expand, simplify, generate flashcards. Full-text and semantic search
5. **Flashcards** — Deck list with due card counts. Review mode: full-screen card flip with rating buttons (Again/Hard/Good/Easy). Create cards manually or from notes. Deck stats: retention rate, review forecast, mature vs young cards. Import/export
6. **AI Study Partner** — Chat interface. Ask questions about your knowledge base. AI retrieves relevant notes and highlights to answer. Suggested questions based on recent learning. "Quiz me on [topic]" mode. "Explain [concept]" mode
7. **Goals** — Active goals list with progress bars. Create goal wizard (select skill, set metric, timeline). Milestone timeline. Weekly check-in prompt. Completed goals archive with celebration
8. **Certifications** — Card grid of certifications with expiry dates. Renewal alerts (90 days, 30 days, expired). Credit tracker per cert. Upload certificates. Link to courses that contributed
9. **Journal** — Calendar view with daily entries. Today's entry editor with prompts ("What did I learn today?", "Key insight:", "Tomorrow I want to learn:"). Mood tracking. Monthly reflection auto-generated by AI from daily entries
10. **Analytics** — Total learning time (week/month/year), time by skill chart, completion rates, streak history, flashcard retention trend, most reviewed topics, knowledge graph visualization showing note connections

### What's the first thing users see after login?

Dashboard showing: learning streak prominently displayed (motivating), flashcards due today (badge with count and "Start Review" button), active courses/books with progress, this week's learning time vs goal, current learning goals with progress. If zero data: onboarding — "What skills do you want to develop?" → "Add your first book or course" → "Write your first note" → "Set a learning goal."

### Any complex interactions?

- **Note Editor with Linking**: Type `[[` to trigger note linking — search and select existing notes to create bi-directional link. Inline preview on hover. Backlinks panel updates in real-time. Slash commands for AI actions (/summarize, /flashcards, /simplify)
- **Flashcard Review Session**: Full-screen focused mode. Show front → user thinks → reveal back → rate (Again/Hard/Good/Easy). SM-2 algorithm calculates next review date. Session summary after completion (cards reviewed, retention rate, streak)
- **AI Study Partner Chat**: Retrieval-augmented generation — AI searches notes via vector embeddings, retrieves relevant context, generates answer citing specific notes. User can click citations to jump to source note. Follow-up questions maintain context
- **Skill Radar Chart**: Interactive radar/spider chart showing all skills. Click a point to adjust level. Drag to set target. Animated transitions when levels change
- **Knowledge Graph**: Visual graph (d3 force-directed) showing notes as nodes and links as edges. Zoom, pan, click to open note. Cluster by topic/tag. Find orphan notes (no links)

### Which screens display a lot of data?

- **Notes** — could be thousands of notes over years, needs full-text search, tag filtering, folder navigation
- **Flashcards** — thousands of cards with review history, needs efficient SM-2 queries
- **Library** — hundreds of books, courses, articles, needs filters and search
- **Analytics** — time-series data across months/years, aggregation queries
- **Knowledge Graph** — rendering many nodes and edges requires efficient graph visualization

---

## Stage 8: Infrastructure

### Environments?
Local + Production

### CI/CD?
GitHub Actions

### Monitoring?
Sentry error tracking, log aggregation

### Special infrastructure needs?
- PostgreSQL with pgvector extension (semantic search)
- Embedding generation service (OpenAI embeddings API or local model)
- File storage (S3-compatible for certificates, covers)
- Scheduled jobs (daily streak calculation, spaced repetition queue preparation, monthly AI journal reflection)
- Background job for embedding generation (when notes are created/updated)
